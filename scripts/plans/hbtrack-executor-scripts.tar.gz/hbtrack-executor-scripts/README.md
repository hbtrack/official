# HB Track — Executor Scripts

Complete toolkit for the Architect-Executor workflow with deterministic AI-powered development.

## Overview

These scripts implement the full workflow described in `hbtrack-arquiteto-executor.docx`:

1. **Architect** (browser AI) produces Plans
2. **Human** validates Plans and orchestrates execution  
3. **Executor** (VS Code AI) implements exactly what's specified
4. **Validation** ensures adherence and quality

---

## Quick Start

### 1. Installation

```bash
# Copy scripts to your HB Track project
cp -r scripts/ /path/to/hbtrack/backend/
cd /path/to/hbtrack/backend

# Make scripts executable
chmod +x scripts/*.py

# Install Python dependencies (if not already installed)
pip install pyyaml --break-system-packages
```

### 2. First-Time Setup

```bash
# Create directory structure
mkdir -p docs/plans docs/implemented docs/metrics

# Initialize metrics file
echo '[]' > docs/metrics/executor_metrics.json

# Initialize locks file
echo 'locked_files: {}' > docs/file_locks.yaml
```

### 3. Execute Your First Plan

```bash
# Generate context for Architect
python scripts/generate_context_snapshot.py > context.txt

# Send context.txt + your request to Architect AI (Claude/GPT/Gemini)
# Receive back: docs/plans/FASE-5-3-v1.0.md

# Run full workflow
python scripts/executor_workflow.py docs/plans/FASE-5-3-v1.0.md
```

---

## Script Reference

### 1. `generate_context_snapshot.py`

**Purpose:** Generate current repo state for the Architect

**Usage:**
```bash
python scripts/generate_context_snapshot.py > context.txt
```

**Output:** Snapshot including:
- Git state (branch, commits, uncommitted files)
- Database schema (models, migrations)
- File structure (app/, tests/)
- Test statistics
- Dependencies
- Invariants
- Environment variables

**When to use:** Before asking Architect to create a new Plan

---

### 2. `validate_plan_adherence.py`

**Purpose:** Check if Executor followed the Plan exactly

**Usage:**
```bash
# Check against main branch
python scripts/validate_plan_adherence.py docs/plans/FASE-5-3.md

# Check against different base branch
python scripts/validate_plan_adherence.py docs/plans/FASE-5-3.md develop
```

**Validates:**
- Files created match specification
- Files modified match specification
- Tests created match specification
- No unexpected changes

**Exit codes:**
- `0` = compliant
- `1` = deviations detected

---

### 3. `check_locks.py`

**Purpose:** Manage file locks for parallel execution

**Usage:**
```bash
# Check if Plan can execute (no conflicts)
python scripts/check_locks.py docs/plans/FASE-5-3.md

# Acquire locks before execution
python scripts/check_locks.py docs/plans/FASE-5-3.md --acquire

# Release locks after completion
python scripts/check_locks.py docs/plans/FASE-5-3.md --release

# List all active locks
python scripts/check_locks.py --list
```

**Lock types:**
- **Exclusive:** Only one Plan can touch this file
- **Shared:** Multiple Plans can read, but not write

**Locks file:** `docs/file_locks.yaml`

---

### 4. `plan_status.py`

**Purpose:** Manage Plan lifecycle and prevent obsolete execution

**Status flow:** `RASCUNHO → EM_REVISAO → APROVADO → EXECUTADO`

**Usage:**
```bash
# Check Plan status
python scripts/plan_status.py docs/plans/FASE-5-3.md

# Update status
python scripts/plan_status.py docs/plans/FASE-5-3.md --set APROVADO

# Mark as executed (moves to implemented/)
python scripts/plan_status.py docs/plans/FASE-5-3.md --executed

# List all Plans by status
python scripts/plan_status.py --list
```

**Protection:** Only Plans with status `APROVADO` can be executed

---

### 5. `validate_dag.py`

**Purpose:** Validate Plan dependencies and execution order

**Usage:**
```bash
# Validate DAG (detect cycles)
python scripts/validate_dag.py docs/plans/fase-5-3-dag.yaml

# Show execution order
python scripts/validate_dag.py docs/plans/fase-5-3-dag.yaml --order

# Check if specific Plan can execute now
python scripts/validate_dag.py docs/plans/fase-5-3-dag.yaml --can-execute FASE-5-3-B
```

**DAG file format:**
```yaml
plans:
  - id: FASE-5-3-A
    depends_on: []
    provides: [model_x]
  
  - id: FASE-5-3-B
    depends_on: [FASE-5-3-A]
    provides: [service_y]
```

**Detects:**
- Circular dependencies
- Missing dependencies
- Execution order violations

---

### 6. `executor_workflow.py` (Main Orchestrator)

**Purpose:** Orchestrate complete workflow with all validations

**Usage:**
```bash
# Full workflow (recommended)
python scripts/executor_workflow.py docs/plans/FASE-5-3.md

# Dry-run only (validate feasibility)
python scripts/executor_workflow.py docs/plans/FASE-5-3.md --dry-run

# Skip dry-run (use with caution!)
python scripts/executor_workflow.py docs/plans/FASE-5-3.md --skip-dry-run
```

**Workflow phases:**
1. **Pre-execution checks** (status, locks, git state)
2. **Dry-run** (feasibility analysis by Executor)
3. **Execution** (actual implementation)
4. **Post-execution validation** (adherence, tests, linters)
5. **Homologation** (manual verification)
6. **Finalization** (commits, status update, release locks)

---

### 7. `record_metrics.py`

**Purpose:** Track ROI of Architect-Executor flow

**Usage:**
```bash
# Record completed task
python scripts/record_metrics.py FASE-5-3 \
  --plan-time 1.5 \
  --exec-time 0.5 \
  --homolog-time 0.3 \
  --bugs 0 \
  --rollbacks 0 \
  --rework 0

# Record baseline task (without flow)
python scripts/record_metrics.py FASE-4-2 \
  --exec-time 3.0 \
  --bugs 2 \
  --rollbacks 1 \
  --rework 4.0 \
  --baseline

# View metrics report
python scripts/record_metrics.py --report

# Compare with vs without flow
python scripts/record_metrics.py --compare
```

**Metrics tracked:**
- Time (plan, execution, homologation, rework)
- Quality (bugs, rollbacks)
- Efficiency (total time, rework %)

**Metrics file:** `docs/metrics/executor_metrics.json`

---

## Complete Workflow Example

### Step 1: Prepare Context

```bash
# Generate snapshot
python scripts/generate_context_snapshot.py > context.txt

# Send to Architect with request:
"""
CONTEXT: [paste context.txt]

REQUEST: Create Plan for athlete registration feature with:
- Endpoint POST /athletes/register
- Validation: CPF, unique membership per team
- Auth: only Treinador and above
- Audit logging for LGPD
"""
```

### Step 2: Receive and Validate Plan

```bash
# Architect returns: docs/plans/FASE-5-3-v1.0.md

# Set status to review
python scripts/plan_status.py docs/plans/FASE-5-3-v1.0.md --set EM_REVISAO

# Manual review using checklist 5.1 from docx

# Approve
python scripts/plan_status.py docs/plans/FASE-5-3-v1.0.md --set APROVADO
```

### Step 3: Execute

```bash
# Run full workflow
python scripts/executor_workflow.py docs/plans/FASE-5-3-v1.0.md

# Workflow will:
# 1. Check prerequisites
# 2. Guide you through dry-run
# 3. Acquire locks
# 4. Pause for you to execute in VS Code
# 5. Validate results
# 6. Guide homologation
# 7. Finalize (status, locks, commits)
```

### Step 4: Record Metrics

```bash
python scripts/record_metrics.py FASE-5-3 \
  --plan-time 1.5 \
  --exec-time 0.5 \
  --homolog-time 0.3 \
  --bugs 0 \
  --rollbacks 0 \
  --rework 0
```

---

## Parallel Execution

### Scenario: Multiple features in same phase

```bash
# Create DAG
cat > docs/plans/fase-5-3-dag.yaml << 'EOF'
plans:
  - id: FASE-5-3-A-MODELS
    depends_on: []
    provides: [models]
  
  - id: FASE-5-3-B-SERVICES
    depends_on: [FASE-5-3-A-MODELS]
    provides: [services]
  
  - id: FASE-5-3-C-ROUTERS
    depends_on: [FASE-5-3-B-SERVICES]
    provides: [routers]
EOF

# Validate DAG
python scripts/validate_dag.py docs/plans/fase-5-3-dag.yaml

# Get execution order
python scripts/validate_dag.py docs/plans/fase-5-3-dag.yaml --order

# Execute in order
python scripts/executor_workflow.py docs/plans/FASE-5-3-A-MODELS.md
# After completion:
python scripts/executor_workflow.py docs/plans/FASE-5-3-B-SERVICES.md
# etc.
```

---

## Troubleshooting

### Problem: "Plan status is not APROVADO"

```bash
# Check current status
python scripts/plan_status.py docs/plans/FASE-5-3.md

# Update status
python scripts/plan_status.py docs/plans/FASE-5-3.md --set APROVADO
```

### Problem: "File locked by another Plan"

```bash
# List active locks
python scripts/check_locks.py --list

# If lock is stale (previous execution failed):
# Manually edit docs/file_locks.yaml and remove the lock
# OR release specific Plan locks:
python scripts/check_locks.py docs/plans/OLD-PLAN.md --release
```

### Problem: "Executor deviated from Plan"

```bash
# Check what changed
python scripts/validate_plan_adherence.py docs/plans/FASE-5-3.md

# If deviations justified:
# 1. Update Plan with actual changes
# 2. Increment version (v1.0 → v1.1)
# 3. Re-run validation
```

### Problem: "Circular dependency in DAG"

```bash
# Validate DAG
python scripts/validate_dag.py docs/plans/fase-5-3-dag.yaml

# Output will show cycle: A → B → C → A
# Fix by breaking one dependency or splitting Plan
```

---

## Integration with Git

### Recommended branch strategy

```bash
# Feature branch
git checkout -b feature/fase-5-3

# For each Plan, create executor branch
git checkout -b executor/FASE-5-3-A

# Executor works here
# After validation, merge back:
git checkout feature/fase-5-3
git merge --squash executor/FASE-5-3-A
git branch -d executor/FASE-5-3-A

# Repeat for each Plan in the feature
```

### Commit message convention

```
[TASK-ID] type: description

Examples:
[FASE-5-3-A] feat(model): add AthleteRegistration model
[FASE-5-3-B] feat(schema): add athlete registration schemas
[FASE-5-3-C] test: add athlete registration tests (176→180 passing)
```

---

## Best Practices

1. **Always generate context snapshot** before requesting new Plans
2. **Always run dry-run** before execution (only skip in emergencies)
3. **Use DAGs** for complex features with multiple Plans
4. **Record metrics** for every task to track ROI
5. **Validate Plan adherence** after each execution
6. **Keep Plans atomic** — one feature, not one phase
7. **Use executor branches** for isolation
8. **Never skip homologation** — it's your final safety net

---

## Files Generated

```
docs/
  plans/                      # Active Plans
    FASE-5-3-v1.0.md
    fase-5-3-dag.yaml
  implemented/                # Executed Plans (archive)
    FASE-5-3-v1.0.md
  metrics/
    executor_metrics.json     # Time, quality, ROI data
  file_locks.yaml             # Active file locks

scripts/
  generate_context_snapshot.py
  validate_plan_adherence.py
  check_locks.py
  plan_status.py
  validate_dag.py
  executor_workflow.py
  record_metrics.py
```

---

## Support

For issues or questions:
1. Review the main document: `hbtrack-arquiteto-executor.docx`
2. Check anti-patterns section (Section 8)
3. Run scripts with `--help` flag (where available)

---

**Version:** 1.0  
**Last updated:** 2025-02-17  
**HB Track Backend**
