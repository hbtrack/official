# HB Track Executor Scripts — Quick Reference Card

## Installation
```bash
# Extract package
tar -xzf hbtrack-executor-scripts.tar.gz
cd hbtrack-executor-scripts

# Install to your project
./install.sh /path/to/hbtrack/backend

# Install Python dependency
pip install pyyaml --break-system-packages
```

## Daily Workflow

### 1. New Feature → Request Plan from Architect
```bash
# Generate context
python scripts/generate_context_snapshot.py > context.txt

# Send to Architect AI:
# - context.txt
# - Your feature request
# - Get back: docs/plans/TASK-ID.md
```

### 2. Validate Plan
```bash
# Set to review
python scripts/plan_status.py docs/plans/TASK-ID.md --set EM_REVISAO

# Review using checklist from docx Section 5.1

# Approve
python scripts/plan_status.py docs/plans/TASK-ID.md --set APROVADO
```

### 3. Execute
```bash
# Full workflow (recommended)
python scripts/executor_workflow.py docs/plans/TASK-ID.md

# The script will guide you through:
# → Pre-execution checks
# → Dry-run
# → Execution
# → Validation
# → Homologation
# → Finalization
```

### 4. Record Metrics
```bash
python scripts/record_metrics.py TASK-ID \
  --plan-time 1.5 --exec-time 0.5 --homolog-time 0.3 \
  --bugs 0 --rollbacks 0 --rework 0
```

## Script Cheat Sheet

| Task | Command |
|------|---------|
| Generate context | `python scripts/generate_context_snapshot.py > context.txt` |
| Check Plan status | `python scripts/plan_status.py PLAN.md` |
| Approve Plan | `python scripts/plan_status.py PLAN.md --set APROVADO` |
| Check locks | `python scripts/check_locks.py PLAN.md` |
| Acquire locks | `python scripts/check_locks.py PLAN.md --acquire` |
| Release locks | `python scripts/check_locks.py PLAN.md --release` |
| Validate DAG | `python scripts/validate_dag.py DAG.yaml` |
| Get exec order | `python scripts/validate_dag.py DAG.yaml --order` |
| Full workflow | `python scripts/executor_workflow.py PLAN.md` |
| Dry-run only | `python scripts/executor_workflow.py PLAN.md --dry-run` |
| Check adherence | `python scripts/validate_plan_adherence.py PLAN.md` |
| View metrics | `python scripts/record_metrics.py --report` |
| Compare metrics | `python scripts/record_metrics.py --compare` |
| List Plans | `python scripts/plan_status.py --list` |
| List locks | `python scripts/check_locks.py --list` |

## Status Flow
```
RASCUNHO → EM_REVISAO → APROVADO → EXECUTADO
```

Only `APROVADO` Plans can be executed.

## Emergency Procedures

### Abort execution mid-way
```bash
# Delete executor branch
git branch -D executor/TASK-ID

# Release locks
python scripts/check_locks.py docs/plans/TASK-ID.md --release

# Revert Plan status
python scripts/plan_status.py docs/plans/TASK-ID.md --set EM_REVISAO
```

### Remove stale lock
```bash
# List locks
python scripts/check_locks.py --list

# Manually edit if needed
nano docs/file_locks.yaml
```

### Fix Plan deviation
```bash
# Check what deviated
python scripts/validate_plan_adherence.py docs/plans/TASK-ID.md

# Option 1: Update Plan to match reality
# Edit Plan, increment version (v1.0 → v1.1)

# Option 2: Revert changes
git checkout HEAD -- [files]
```

## Parallel Execution

### When executing multiple Plans:
1. Create DAG file: `docs/plans/feature-dag.yaml`
2. Validate: `python scripts/validate_dag.py feature-dag.yaml`
3. Get order: `python scripts/validate_dag.py feature-dag.yaml --order`
4. Execute in order, checking dependencies

### Lock conflicts:
- Plans touching same files must run sequentially
- Check locks before acquiring: `python scripts/check_locks.py PLAN.md`

## Metrics

### Track every task:
```bash
# With flow
python scripts/record_metrics.py TASK-ID \
  --plan-time H --exec-time H --homolog-time H \
  --bugs N --rollbacks N --rework H

# Without flow (baseline)
python scripts/record_metrics.py TASK-ID \
  --exec-time H --bugs N --rollbacks N --rework H \
  --baseline
```

### Analyze ROI:
```bash
# View report
python scripts/record_metrics.py --report

# Compare with/without flow
python scripts/record_metrics.py --compare
```

## Git Integration

### Branch strategy:
```bash
# Feature branch
git checkout -b feature/fase-X

# Executor branch (per Plan)
git checkout -b executor/TASK-ID

# After validation
git checkout feature/fase-X
git merge --squash executor/TASK-ID
git branch -d executor/TASK-ID
```

### Commit convention:
```
[TASK-ID] type: description

Examples:
[FASE-5-3-A] feat(model): add AthleteRegistration
[FASE-5-3-B] test: add registration tests (176→180)
```

## Files Structure
```
docs/
  plans/              # Active Plans (RASCUNHO, EM_REVISAO, APROVADO)
  implemented/        # Executed Plans archive
  metrics/
    executor_metrics.json
  file_locks.yaml

scripts/
  generate_context_snapshot.py
  validate_plan_adherence.py
  check_locks.py
  plan_status.py
  validate_dag.py
  executor_workflow.py
  record_metrics.py
```

## Support
- Main doc: `hbtrack-arquiteto-executor.docx`
- Full guide: `docs/EXECUTOR_SCRIPTS.md`
- Script help: `python scripts/SCRIPT.py --help` (where available)

---
**HB Track Backend** • **Version 1.0** • **2025-02-17**
