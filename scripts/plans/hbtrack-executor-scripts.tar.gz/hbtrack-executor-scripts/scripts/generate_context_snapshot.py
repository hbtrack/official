#!/usr/bin/env python3
"""
Generate Context Snapshot for Architect
========================================
Collects current repo state to send to the Architect AI.
Prevents the Architect from making technically impossible plans.

Usage:
    python scripts/generate_context_snapshot.py > context.txt
    # Then send context.txt to the Architect along with your request
"""

import subprocess
import sys
from pathlib import Path
from datetime import datetime
import json


def run_cmd(cmd: str, cwd: str = ".") -> str:
    """Execute shell command and return output."""
    try:
        result = subprocess.run(
            cmd,
            shell=True,
            cwd=cwd,
            capture_output=True,
            text=True,
            timeout=10
        )
        return result.stdout.strip()
    except Exception as e:
        return f"[ERROR: {e}]"


def get_git_info():
    """Collect Git state."""
    return {
        "branch": run_cmd("git branch --show-current"),
        "last_commit": run_cmd("git log -1 --oneline"),
        "uncommitted_files": run_cmd("git status --short"),
    }


def get_database_schema():
    """Collect current database schema info."""
    schema = {
        "current_migration": run_cmd("alembic current 2>/dev/null || echo 'N/A'"),
        "pending_migrations": run_cmd("alembic heads 2>/dev/null || echo 'N/A'"),
    }
    
    # Try to get table list from models
    models_dir = Path("app/models")
    if models_dir.exists():
        model_files = [f.name for f in models_dir.glob("*.py") if f.name != "__init__.py"]
        schema["model_files"] = model_files
    
    return schema


def get_file_structure():
    """Get relevant directory structure."""
    structure = {}
    
    important_dirs = ["app/models", "app/routers", "app/schemas", "app/services", "tests"]
    
    for dir_path in important_dirs:
        if Path(dir_path).exists():
            result = run_cmd(f"tree -L 2 {dir_path} 2>/dev/null || find {dir_path} -type f -name '*.py' | head -20")
            structure[dir_path] = result
    
    return structure


def get_test_stats():
    """Get test suite statistics."""
    pytest_output = run_cmd("pytest --collect-only -q 2>/dev/null | tail -5")
    return {
        "pytest_collection": pytest_output,
        "test_files": run_cmd("find tests -name 'test_*.py' | wc -l"),
    }


def get_dependencies():
    """Get installed dependencies."""
    deps = {}
    
    if Path("requirements.txt").exists():
        deps["requirements"] = Path("requirements.txt").read_text().strip().split("\n")[:20]
    
    if Path("pyproject.toml").exists():
        deps["pyproject_exists"] = True
    
    return deps


def get_invariants():
    """Get documented invariants."""
    invariants_file = Path("docs/invariants.md")
    if invariants_file.exists():
        content = invariants_file.read_text()
        # Extract just the invariant IDs
        lines = [l.strip() for l in content.split("\n") if l.strip().startswith("INV-")]
        return lines[:20]  # First 20 invariants
    return []


def get_recent_migrations():
    """Get last 3 migrations."""
    migrations_dir = Path("alembic/versions")
    if migrations_dir.exists():
        migrations = sorted(migrations_dir.glob("*.py"), key=lambda p: p.stat().st_mtime, reverse=True)
        return [m.name for m in migrations[:3]]
    return []


def get_env_vars():
    """Get required environment variables (names only, not values)."""
    env_file = Path(".env.example")
    if env_file.exists():
        lines = env_file.read_text().strip().split("\n")
        return [l.split("=")[0] for l in lines if "=" in l and not l.startswith("#")]
    return []


def main():
    print("=" * 80)
    print("HB TRACK — CONTEXT SNAPSHOT FOR ARCHITECT")
    print("=" * 80)
    print(f"Generated at: {datetime.now().isoformat()}")
    print(f"Working directory: {Path.cwd()}")
    print()
    
    print("## GIT STATE")
    print("-" * 80)
    git_info = get_git_info()
    for key, value in git_info.items():
        print(f"{key}: {value}")
    print()
    
    print("## DATABASE SCHEMA")
    print("-" * 80)
    schema = get_database_schema()
    for key, value in schema.items():
        if isinstance(value, list):
            print(f"{key}:")
            for item in value:
                print(f"  - {item}")
        else:
            print(f"{key}: {value}")
    print()
    
    print("## FILE STRUCTURE")
    print("-" * 80)
    structure = get_file_structure()
    for dir_path, content in structure.items():
        print(f"\n{dir_path}:")
        print(content)
    print()
    
    print("## TEST STATISTICS")
    print("-" * 80)
    test_stats = get_test_stats()
    for key, value in test_stats.items():
        print(f"{key}: {value}")
    print()
    
    print("## DEPENDENCIES")
    print("-" * 80)
    deps = get_dependencies()
    if "requirements" in deps:
        print("Key requirements (first 20):")
        for req in deps["requirements"]:
            if req.strip():
                print(f"  - {req}")
    print()
    
    print("## INVARIANTS")
    print("-" * 80)
    invariants = get_invariants()
    if invariants:
        print(f"Total invariants documented: {len(invariants)}")
        for inv in invariants:
            print(f"  {inv}")
    else:
        print("No invariants documented yet.")
    print()
    
    print("## RECENT MIGRATIONS")
    print("-" * 80)
    migrations = get_recent_migrations()
    if migrations:
        print("Last 3 migrations:")
        for m in migrations:
            print(f"  - {m}")
    else:
        print("No migrations found.")
    print()
    
    print("## REQUIRED ENVIRONMENT VARIABLES")
    print("-" * 80)
    env_vars = get_env_vars()
    if env_vars:
        for var in env_vars:
            print(f"  - {var}")
    else:
        print("No .env.example found.")
    print()
    
    print("=" * 80)
    print("END OF SNAPSHOT")
    print("=" * 80)
    print()
    print("INSTRUCTIONS FOR ARCHITECT:")
    print("- Use this snapshot to understand current repo state")
    print("- Do NOT specify changes to files/tables that don't exist")
    print("- Do NOT create migrations for tables that already exist")
    print("- Verify your Plan against this snapshot before declaring it complete")


if __name__ == "__main__":
    main()
