#!/bin/bash
# HB Track Executor Scripts — Installation Script
# Usage: ./install.sh /path/to/hbtrack/backend

set -e

if [ -z "$1" ]; then
    echo "Usage: ./install.sh /path/to/hbtrack/backend"
    exit 1
fi

TARGET_DIR="$1"

if [ ! -d "$TARGET_DIR" ]; then
    echo "Error: Target directory does not exist: $TARGET_DIR"
    exit 1
fi

echo "Installing HB Track Executor Scripts to: $TARGET_DIR"
echo ""

# Copy scripts
echo "→ Copying scripts..."
mkdir -p "$TARGET_DIR/scripts"
cp scripts/*.py "$TARGET_DIR/scripts/"
chmod +x "$TARGET_DIR/scripts"/*.py
echo "  ✓ Scripts copied and made executable"

# Create directory structure
echo "→ Creating directory structure..."
mkdir -p "$TARGET_DIR/docs/plans"
mkdir -p "$TARGET_DIR/docs/implemented"
mkdir -p "$TARGET_DIR/docs/metrics"
echo "  ✓ Directories created"

# Initialize files
echo "→ Initializing files..."

if [ ! -f "$TARGET_DIR/docs/metrics/executor_metrics.json" ]; then
    echo "[]" > "$TARGET_DIR/docs/metrics/executor_metrics.json"
    echo "  ✓ executor_metrics.json created"
else
    echo "  ⊙ executor_metrics.json already exists (skipped)"
fi

if [ ! -f "$TARGET_DIR/docs/file_locks.yaml" ]; then
    echo "locked_files: {}" > "$TARGET_DIR/docs/file_locks.yaml"
    echo "  ✓ file_locks.yaml created"
else
    echo "  ⊙ file_locks.yaml already exists (skipped)"
fi

# Copy example DAG
if [ ! -f "$TARGET_DIR/docs/plans/fase-5-3-dag.yaml" ]; then
    cp docs/plans/fase-5-3-dag.yaml "$TARGET_DIR/docs/plans/"
    echo "  ✓ Example DAG copied"
else
    echo "  ⊙ DAG file already exists (skipped)"
fi

# Copy README
echo "→ Copying documentation..."
cp README.md "$TARGET_DIR/docs/EXECUTOR_SCRIPTS.md"
echo "  ✓ Documentation copied to docs/EXECUTOR_SCRIPTS.md"

echo ""
echo "═══════════════════════════════════════════════════════════════════════════"
echo "✅ Installation complete!"
echo "═══════════════════════════════════════════════════════════════════════════"
echo ""
echo "Next steps:"
echo ""
echo "  1. Read documentation:"
echo "     cat $TARGET_DIR/docs/EXECUTOR_SCRIPTS.md"
echo ""
echo "  2. Install Python dependencies (if needed):"
echo "     pip install pyyaml --break-system-packages"
echo ""
echo "  3. Generate context snapshot:"
echo "     cd $TARGET_DIR"
echo "     python scripts/generate_context_snapshot.py > context.txt"
echo ""
echo "  4. Send context.txt to Architect AI to create your first Plan"
echo ""
echo "  5. Execute your first Plan:"
echo "     python scripts/executor_workflow.py docs/plans/YOUR-PLAN.md"
echo ""
echo "═══════════════════════════════════════════════════════════════════════════"
